#include<stdio.h>

int addnum(int a, int b);

int main(int argc, char *argv[]){
int total;
total = addnum(6,2);
printf("total = %d\n",total);
return 0;
}

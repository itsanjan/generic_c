#include<stdio.h>

int addnum(int a, int b)
{
int sum;
sum = a + b;
return sum;
}

/* filename: driver.c  */
#include "lib_mylib.h"
void main()
{
  fun();
}

/* Filename: lib_mylib.h */
void fun(void);
